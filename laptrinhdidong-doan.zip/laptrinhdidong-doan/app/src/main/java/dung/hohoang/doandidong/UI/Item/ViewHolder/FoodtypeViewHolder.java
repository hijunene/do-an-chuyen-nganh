package dung.hohoang.doandidong.UI.Item.ViewHolder;

import android.widget.ImageView;
import android.widget.TextView;

public class FoodtypeViewHolder {
    private ImageView imgFoodType;
    private TextView txtTitle;

    public ImageView getImgFoodType() {
        return imgFoodType;
    }

    public void setImgFoodType(ImageView imgFoodType) {
        this.imgFoodType = imgFoodType;
    }

    public TextView getTxtTitle() {
        return txtTitle;
    }

    public void setTxtTitle(TextView txtTitle) {
        this.txtTitle = txtTitle;
    }
}
